---
name: editar-reels-jornada-3d
description: Cria reels verticais (9:16) no formato JORNADA 3D LOW-POLY com Remotion + @remotion/three. Um boneco anda por uma trilha de hexágonos; cada etapa de um processo (funil, método, serviço, passo a passo) vira uma estação com objetos 3D, etiquetas e título; som de jogo em tudo; no fim a câmera sobe e mostra a trilha inteira com tudo o que foi feito + "PARABÉNS!". Usar quando pedirem "jornada 3D", "bonequinho andando nos hexágonos", "estilo low-poly/jogo", "explicar as etapas como um caminho". Parte de um roteiro + narração, sem gravação de câmera.
---

# Reels: formato jornada 3D low-poly

Monte o vídeo em `src/videos/<slug>/Video.tsx` do seu projeto Remotion seguindo a estrutura abaixo (exemplo validado: "Do seu WhatsApp ao agente no ar", 45 s).

## Regras do formato

1. **Sempre 9:16, 1080×1920, 30 fps.** Confirme com quem pediu se o roteiro disser outra coisa.
2. **Som em tudo.** É animação de jogo: passos ao andar, "level up" quando o hexágono acende, pop em cada objeto, som do que se vê (papel, notificação, check), fanfarra no final. Sons em `public/sfx/` (prompts para gerar no ElevenLabs Sound Effects no fim deste arquivo).
3. **Trilha cheia no zoom-out.** Nada some: cada estação mantém seus objetos e ganha um boneco; a câmera sobe e mostra tudo.
4. **Narração aprovada antes de animar.** Pergunte qual voz usar; não gere áudio de novo se já houver um aprovado.
5. Final com **"PARABÉNS!"** + a frase do resultado.

## Fluxo

1. **Roteiro em estações:** abertura (o problema) → 3 a 6 estações → zoom-out → parabéns. Por estação: título curto ("2. TREINAMENTO"), 2 a 4 objetos, 1 ou 2 etiquetas, uma frase de narração. Uns 120 palavras dão ~45 s.
2. **Narração** (ElevenLabs ou voz gravada) → aprovação.
3. **Transcrição palavra a palavra** em `words.json` (`[{text, startMs, endMs}]`). Sem vídeo, gere um vídeo preto com o áudio e transcreva com Whisper (`@remotion/install-whisper-cpp`):
   `ffmpeg -f lavfi -i color=c=black:s=1280x720:r=30 -i narracao.mp3 -shortest -c:v libx264 -c:a aac bruto.mp4`
   **Revise o `words.json`**: o Whisper costuma errar palavras de voz sintética.
4. **Montar**: definir `T` (gatilhos por palavra com `tl.at('palavra')`), `STARTS`/`ENDS`, componentes `StationN`, `NODES`, `Overlay` (títulos e pílulas) e `SoundMap`. Registrar no `Root.tsx` com `width={1080} height={1920} fps={30}`.
5. **Conferir quadros antes do render:**
   `npx remotion still <Id> saida/s<f>.jpg --frame=<f> --gl=angle --scale=0.4` em cada estação, no zoom-out e no parabéns.
6. **Render:** `npx remotion render <Id> saida/<slug>.mp4 --gl=angle --concurrency=4`.
7. **Volume final:** `ffmpeg -i x.mp4 -c:v copy -af loudnorm=I=-14:TP=-1:LRA=11 -c:a aac -b:a 256k x-final.mp4` (o render costuma sair abaixo de −14 LUFS).

## Instalação no projeto Remotion

`npm i @remotion/three three @react-three/fiber @types/three @remotion/google-fonts` (testado com Remotion 4.0.534, three 0.178, @react-three/fiber 9.3, React 19). Render e still **sempre com `--gl=angle`**, senão o 3D não aparece.

## Como montar (o que não quebrar)

- **Low-poly sem baixar modelo:** hexágono = `cylinderGeometry(r, r, h, 6)`; árvore = cone ou icosaedro de detalhe 0 + tronco; boneco = caixas + esfera; nuvem = 4 icosaedros brancos. Material `meshStandardMaterial` com `flatShading`.
- **Uma só função de câmera** `camState(frame)` move a câmera 3D (`CameraRig`) e projeta as etiquetas HTML (`makeCam` + `Vector3.project`): a pílula fica presa ao objeto durante qualquer movimento.
- **Câmera vertical que funcionou:** fov 55; perto = posição (1,2, 7,6, z+12,8) olhando para (1,1, 2,3, z−2); zoom-out = (6, 31, início+21) olhando para o meio da trilha. Estações a cada 8 unidades em −z; boneco em x −1,3; objetos de x 0 a 3,7.
- **Estação some enquanto a câmera passa por ela** e volta no zoom-out. Sem isso, os objetos da estação anterior aparecem gigantes em primeiro plano.
- **Pílulas presas dentro da tela** (clamp pela largura estimada do texto). Etiquetas vizinhas em alturas alternadas para não se baterem.
- **Overlay:** título da estação em y 250 (76 px, amarelo, contorno 14 px); legenda uma palavra por vez em y 1340 (100 px, palavra-chave em amarelo); parabéns em y 260. Zona segura do Instagram: y 220 a 1550.
- **Luz:** `ambientLight` + `hemisphereLight` + `directionalLight` com sombra. Sem a luz ambiente, os rostos saem escuros. Noite = interpolar a cor do céu e da névoa e baixar as luzes.
- **Árvores** com faixa livre do lado da câmera, senão tapam a cena.
- **Mola:** objetos entram com `spring` (damping ~9–10, mass 0,6), sempre na palavra que os cita.

## Prompts dos sons (ElevenLabs Sound Effects)

- `levelup` (1,2 s, hexágono acende): Cheerful mobile game level up chime, bright ascending sparkle, short and clean, cartoon style
- `passos` (1 s, boneco andando): Cartoon character quick light footsteps on stone path, playful, about six steps
- `pop3d` (0,5 s, objeto surgindo): Bubbly cartoon pop, object popping into existence in a mobile game, soft and satisfying
- `absorver` (0,8 s, item entrando em outro objeto): Magical whoosh into a glowing brain, sparkly absorb sound, cartoon
- `noite` (1,5 s, céu escurece): Night falls magical transition, soft crickets and gentle shimmer, cartoon
- `vitoria` (3 s, parabéns): Short cartoon victory fanfare with confetti party popper and kids cheering, mobile game level complete

Volumes entre 0,15 e 0,5, sempre abaixo da voz.
